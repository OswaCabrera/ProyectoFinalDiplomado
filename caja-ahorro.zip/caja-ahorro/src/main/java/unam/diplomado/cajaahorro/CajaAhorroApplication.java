package unam.diplomado.cajaahorro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CajaAhorroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CajaAhorroApplication.class, args);
	}

}
